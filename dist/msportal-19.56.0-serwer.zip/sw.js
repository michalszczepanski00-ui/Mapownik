/*
 * msportal — service worker (tryb offline). PLIK GENEROWANY przez tools/build.mjs z tools/sw.template.js.
 *
 * Co działa bez internetu: aplikacja się otwiera, projekt (IndexedDB) można przeglądać, rysować i zapisywać
 * do pliku. Czego nie ma bez internetu: podkładów i warstw map, karty działki, raportów — to dane z usług.
 *
 * Zasady:
 *  - strona (index.html) — najpierw sieć (max 4 s), bez sieci zapamiętana kopia: po wdrożeniu nowej wersji
 *    użytkownik z siecią zawsze dostaje nową stronę;
 *  - assets/build/* — z pamięci (nazwy plików zawierają sumę treści, więc się nie zmieniają); wszystkie
 *    pliki paczki są zapamiętywane przy instalacji;
 *  - api/, kafle map (inne domeny), diagnostyka, app-*, vendor/ — zawsze z sieci, bez zapamiętywania.
 * Awaryjne wyłączenie: zastąp na serwerze sw.js plikiem assets/sw-wylacz.js (instrukcja w ZMIANY_19.43.0.md).
 */
const VERSION = "19.56.0-73789748db";
const CACHE = `msportal-${VERSION}`;
const PRECACHE = [
 "./",
 "./index.html",
 "./assets/js/boot.js?v=19.56.0",
 "./manifest.webmanifest",
 "./assets/icons/icon-192.png",
 "./assets/icons/icon-512.png",
 "./assets/build/AnalysesPanel-DOppADAT.js",
 "./assets/build/AnalysisPanel-DH8a-Un7.js",
 "./assets/build/AnalysisResultsPanel-BSImVHcu.js",
 "./assets/build/BuildingPermitsPanel-BxyCVxe-.js",
 "./assets/build/ExportPanel-CQVr8-h8.js",
 "./assets/build/GeoJSON-DLvVWGzK.js",
 "./assets/build/LayersPanel-CBGhYXfS.js",
 "./assets/build/MarketPricesPanel-CFklsvzz.js",
 "./assets/build/ObjectsPanel-cd-dwNlB.js",
 "./assets/build/Pagination-BGgx9lmn.js",
 "./assets/build/PanelHeaderActions-d-rUYAhk.js",
 "./assets/build/ParcelComparisonPanel-BErogzGJ.js",
 "./assets/build/ReportPdfDialog-CD-1XMeU.js",
 "./assets/build/Source-C0gttZau.js",
 "./assets/build/Terrain3DView-DZiYG0ZS.js",
 "./assets/build/TerrainProfilePanel-CWhqudfr.js",
 "./assets/build/Vector-CY2MHPsS.js",
 "./assets/build/VpsDataPanel-xYlbHclA.js",
 "./assets/build/apiCache-D7Q-0auL.js",
 "./assets/build/coverageCache-JJGQw_Mm.js",
 "./assets/build/editingModeTool-ClU3pL-p.js",
 "./assets/build/fira-sans-condensed-latin-400-BmvZHCvU.woff2",
 "./assets/build/fira-sans-condensed-latin-600-CdJSnjCb.woff2",
 "./assets/build/fira-sans-condensed-latin-ext-400-BHj09Mzt.woff2",
 "./assets/build/fira-sans-condensed-latin-ext-600-10nHsj_O.woff2",
 "./assets/build/fira-sans-latin-400-a0AnQzuD.woff2",
 "./assets/build/fira-sans-latin-600-CXKlxLG9.woff2",
 "./assets/build/fira-sans-latin-700-CRhwpWTq.woff2",
 "./assets/build/fira-sans-latin-ext-400-BLG_mAEf.woff2",
 "./assets/build/fira-sans-latin-ext-600-DTQBTt1m.woff2",
 "./assets/build/fira-sans-latin-ext-700-g2Yrd4J5.woff2",
 "./assets/build/i18n-BKj38m8o.js",
 "./assets/build/icons-BdbkpPoL.js",
 "./assets/build/identifyTool-pqIPxyKo.js",
 "./assets/build/interactionCoordinator-C85nmfJ3.js",
 "./assets/build/jsts-buffer.esm-BhDiO2h4.js",
 "./assets/build/main-B3sbXiq6.js",
 "./assets/build/main-CzXV6Jlc.css",
 "./assets/build/mapownik-logo-icon-_z1Cl8iY.png",
 "./assets/build/measurementModeTool-BOI7R74O.js",
 "./assets/build/parcelTool--B9wmBXL.js",
 "./assets/build/preload-helper-DclECHGd.js",
 "./assets/build/profileChart-D_2YGo8l.js",
 "./assets/build/rcnDefaults-DcX3Lroa.js",
 "./assets/build/react-dom-BNHr3paL.js",
 "./assets/build/reportData-BCTaMSrY.js",
 "./assets/build/reportDialogStore-uuXfG1CZ.js",
 "./assets/build/reportPdf-Dx48cigV.js",
 "./assets/build/rolldown-runtime-XKyaHtl9.js",
 "./assets/build/screenExport-Dqmxzb_0.js",
 "./assets/build/tablerIcons-CYyV6MPC.js",
 "./assets/build/terrain3dTool-CQsAijlR.js",
 "./assets/build/terrainAreaTool-CPVEPiw3.js",
 "./assets/build/terrainGrid-Bmz-Crfb.js",
 "./assets/build/terrainProfileTool-Deo63BJv.js",
 "./assets/build/terrainReport-O06coO8J.js",
 "./assets/build/terrainScene-F8efBEDD.js",
 "./assets/build/terrainSurface.worker-BP3WbkSd.js",
 "./assets/build/units-B35Blags.js",
 "./assets/build/wmsAdapter-T6SShm-x.js",
 "./assets/build/zod-CUGnsiqq.js"
];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(PRECACHE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    for (const key of await caches.keys()) if (key.startsWith('msportal-') && key !== CACHE) await caches.delete(key);
    await self.clients.claim();
  })());
});

const scopeUrl = new URL(self.registration.scope);
const inScope = (url) => url.origin === scopeUrl.origin && url.pathname.startsWith(scopeUrl.pathname);
const rel = (url) => url.pathname.slice(scopeUrl.pathname.length);

async function networkFirstPage(request) {
  const cache = await caches.open(CACHE);
  try {
    const response = await Promise.race([
      fetch(request),
      new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 4000)),
    ]);
    if (response.ok && response.type === 'basic') await cache.put('./index.html', response.clone());
    return response;
  } catch {
    return (await cache.match('./index.html')) || (await cache.match('./')) || Response.error();
  }
}

async function cacheFirst(request) {
  const cache = await caches.open(CACHE);
  const hit = await cache.match(request);
  if (hit) return hit;
  const response = await fetch(request);
  if (response.ok) await cache.put(request, response.clone());
  return response;
}

async function staleWhileRevalidate(request) {
  const cache = await caches.open(CACHE);
  const hit = await cache.match(request);
  const update = fetch(request).then((response) => { if (response.ok) void cache.put(request, response.clone()); return response; }).catch(() => hit);
  return hit || update;
}

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (!inScope(url)) return; // kafle i usługi zewnętrzne — bez udziału service workera
  const path = rel(url);
  if (request.mode === 'navigate') {
    // Tylko strona aplikacji; diagnostyka, monitor i pliki PHP idą prosto do serwera.
    if (path === '' || path === 'index.html') event.respondWith(networkFirstPage(request));
    return;
  }
  if (path.startsWith('assets/build/')) { event.respondWith(cacheFirst(request)); return; }
  if (path === 'assets/js/boot.js' || path === 'manifest.webmanifest' || path.startsWith('assets/icons/')) {
    event.respondWith(staleWhileRevalidate(request));
  }
});
