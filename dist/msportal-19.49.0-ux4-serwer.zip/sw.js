/*
 * msportal — service worker (tryb offline). PLIK GENEROWANY przez tools/build.mjs z tools/sw.template.js.
 *
 * Co działa bez internetu: aplikacja się otwiera, projekt (IndexedDB) można przeglądać, rysować i zapisywać
 * do pliku. Czego nie ma bez internetu: podkładów i warstw map, karty działki, raportów — to dane z usług.
 *
 * Zasady:
 *  - strona (index.html) — najpierw sieć (max 4 s), bez sieci zapamiętana kopia: po wdrożeniu nowej wersji
 *    użytkownik z siecią zawsze dostaje nową stronę;
 *  - assets/build/* — z pamięci (nazwy plików zawierają sumę treści, więc się nie zmieniają); wszystkie
 *    pliki paczki są zapamiętywane przy instalacji;
 *  - api/, kafle map (inne domeny), diagnostyka, app-*, vendor/ — zawsze z sieci, bez zapamiętywania.
 * Awaryjne wyłączenie: zastąp na serwerze sw.js plikiem assets/sw-wylacz.js (instrukcja w ZMIANY_19.43.0.md).
 */
const VERSION = "19.49.0-ux4-12f0992948";
const CACHE = `msportal-${VERSION}`;
const PRECACHE = [
 "./",
 "./index.html",
 "./assets/js/boot.js?v=19.49.0",
 "./assets/js/ux.js?v=19.49.0-ux4",
 "./assets/css/95-odswiezenie.css?v=19.49.0-ux4",
 "./manifest.webmanifest",
 "./assets/icons/icon-192.png",
 "./assets/icons/icon-512.png",
 "./assets/build/AnalysisPanel-Cy7HwTdE.js",
 "./assets/build/AnalysisResultsPanel-CzYocSX-.js",
 "./assets/build/BuildingPermitsPanel-ggN9-gZN.js",
 "./assets/build/ExportPanel-mm0T_iKG.js",
 "./assets/build/GeoJSON-DLvVWGzK.js",
 "./assets/build/LayersPanel-BIbCOqFO.js",
 "./assets/build/MarketPricesPanel-PKQglO7B.js",
 "./assets/build/ObjectsPanel-DaEndHlt.js",
 "./assets/build/Pagination-BKjgXQKb.js",
 "./assets/build/PanelHeaderActions-CCNPFvIR.js",
 "./assets/build/ParcelComparisonPanel-69jr6OOe.js",
 "./assets/build/ReportPdfDialog-BCdx0jxq.js",
 "./assets/build/Source-C0gttZau.js",
 "./assets/build/Terrain3DView-DYoYBxRr.js",
 "./assets/build/TerrainProfilePanel-ck2pJr6Y.js",
 "./assets/build/Vector-CY2MHPsS.js",
 "./assets/build/VpsDataPanel-4YlBWILp.js",
 "./assets/build/apiCache-D7Q-0auL.js",
 "./assets/build/coverageCache-DB33kFVc.js",
 "./assets/build/editingModeTool-ClU3pL-p.js",
 "./assets/build/fetchRetry-Ccz5cmwx.js",
 "./assets/build/i18n-D--pvsv8.js",
 "./assets/build/icons-BdbkpPoL.js",
 "./assets/build/identifyTool-pqIPxyKo.js",
 "./assets/build/inter-latin-400-BOOGhInR.woff2",
 "./assets/build/inter-latin-500-D2bGa7uu.woff2",
 "./assets/build/inter-latin-600-D273HNI0.woff2",
 "./assets/build/inter-latin-700-Sckx8rpT.woff2",
 "./assets/build/inter-latin-ext-400-hnt3BR84.woff2",
 "./assets/build/inter-latin-ext-500-CIS2RHJS.woff2",
 "./assets/build/inter-latin-ext-600-BnYJhD27.woff2",
 "./assets/build/inter-latin-ext-700-CzikT_rs.woff2",
 "./assets/build/interactionCoordinator-C85nmfJ3.js",
 "./assets/build/jsts-buffer.esm-BhDiO2h4.js",
 "./assets/build/main-DPpsPZml.js",
 "./assets/build/main-TOCWuKAI.css",
 "./assets/build/mapownik-logo-icon-_z1Cl8iY.png",
 "./assets/build/measurementModeTool-BOI7R74O.js",
 "./assets/build/parcelTool--B9wmBXL.js",
 "./assets/build/preload-helper-DclECHGd.js",
 "./assets/build/profileChart-D_2YGo8l.js",
 "./assets/build/rcnDefaults-DcX3Lroa.js",
 "./assets/build/react-dom-BNHr3paL.js",
 "./assets/build/reportData-BElUJpqm.js",
 "./assets/build/reportDialogStore-DalZYJ9X.js",
 "./assets/build/reportPdf-Bkbmb7wB.js",
 "./assets/build/rolldown-runtime-XKyaHtl9.js",
 "./assets/build/runTerrainFor-BeStCWO_.js",
 "./assets/build/screenExport-x-RXTnpx.js",
 "./assets/build/tablerIcons-LOVcS8mZ.js",
 "./assets/build/terrain3dTool-C-JSX9h4.js",
 "./assets/build/terrainAreaTool-CPVEPiw3.js",
 "./assets/build/terrainGrid-BnHt2Zlf.js",
 "./assets/build/terrainProfileTool-Deo63BJv.js",
 "./assets/build/terrainReport-C3mUGrm4.js",
 "./assets/build/terrainScene-B1zePDVU.js",
 "./assets/build/terrainSurface.worker-BP3WbkSd.js",
 "./assets/build/ui-Hf-2wYMX.js",
 "./assets/build/units-B35Blags.js",
 "./assets/build/wmsAdapter-CNcq4-0F.js",
 "./assets/build/zod-CUGnsiqq.js"
];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(PRECACHE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    for (const key of await caches.keys()) if (key.startsWith('msportal-') && key !== CACHE) await caches.delete(key);
    await self.clients.claim();
  })());
});

const scopeUrl = new URL(self.registration.scope);
const inScope = (url) => url.origin === scopeUrl.origin && url.pathname.startsWith(scopeUrl.pathname);
const rel = (url) => url.pathname.slice(scopeUrl.pathname.length);

async function networkFirstPage(request) {
  const cache = await caches.open(CACHE);
  try {
    const response = await Promise.race([
      fetch(request),
      new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 4000)),
    ]);
    if (response.ok && response.type === 'basic') await cache.put('./index.html', response.clone());
    return response;
  } catch {
    return (await cache.match('./index.html')) || (await cache.match('./')) || Response.error();
  }
}

async function cacheFirst(request) {
  const cache = await caches.open(CACHE);
  const hit = await cache.match(request);
  if (hit) return hit;
  const response = await fetch(request);
  if (response.ok) await cache.put(request, response.clone());
  return response;
}

async function staleWhileRevalidate(request) {
  const cache = await caches.open(CACHE);
  const hit = await cache.match(request);
  const update = fetch(request).then((response) => { if (response.ok) void cache.put(request, response.clone()); return response; }).catch(() => hit);
  return hit || update;
}

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (!inScope(url)) return; // kafle i usługi zewnętrzne — bez udziału service workera
  const path = rel(url);
  if (request.mode === 'navigate') {
    // Tylko strona aplikacji; diagnostyka, monitor i pliki PHP idą prosto do serwera.
    if (path === '' || path === 'index.html') event.respondWith(networkFirstPage(request));
    return;
  }
  if (path.startsWith('assets/build/')) { event.respondWith(cacheFirst(request)); return; }
  if (path === 'assets/js/boot.js' || path === 'assets/js/ux.js' || path === 'assets/css/95-odswiezenie.css' || path === 'manifest.webmanifest' || path.startsWith('assets/icons/')) {
    event.respondWith(staleWhileRevalidate(request));
  }
});
