Tutaj wgraj przez FTP plik msportal.sqlite3 przygotowany narzędziem importu
(narzedzia_importu, polecenie „przygotuj”). Katalog jest zablokowany dla przeglądarek.
