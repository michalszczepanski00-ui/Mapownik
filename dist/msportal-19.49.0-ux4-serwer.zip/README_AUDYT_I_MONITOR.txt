MAPOWNIK 18.18.4 — ŹRÓDŁA I MONITOR

Aktualna instrukcja: README_WGRAJ_NA_SERWER.txt.
Zmiany i testy: audyt/wdrozenie-18.18.0.html i ZMIANY_18.18.0.md.
Monitor 70 pozycji: monitor-zrodel.html. W aplikacji: Ustawienia → Monitor.
Szczegóły rozróżniają datę danych, sprawdzenie konfiguracji i czas próby.
Pusty obraz nie dowodzi braku ograniczeń. HTTP 200 z HTML nie jest mapą.
Historia nowej konfiguracji zaczyna się od nowa; zapisuje 20 ostatnich prób.
W tle i offline próby automatyczne są wstrzymane. Eksport JSON/CSV pozostaje.
Starsze raporty opisują wcześniejsze wersje; raporty w audyt/ dotyczą 18.18.0; 18.18.1 i 18.18.2 zmieniają układ, czcionkę i drobne zachowania interfejsu (patrz ZMIANY_18.18.1.md i ZMIANY_18.18.2.md).
